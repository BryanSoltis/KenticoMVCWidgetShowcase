SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_CMS_EventLog_DeleteOlderLogs]
	@SiteId int,
	@LogMaxSize int,
	@MaxToDelete int
AS

--exec Proc_CMS_EventLog_DeleteOlderLogs @LogMaxSize=1000,@SiteId=0,@MaxToDelete=50000

--DECLARE
--	@SiteId int,
--	@LogMaxSize int,
--	@MaxToDelete int

--SET @SiteId = 0	
--SET @LogMaxSize = 1000
--SET @MaxToDelete = 50000

IF @SiteId > 0 
BEGIN
	;WITH SiteEventsRowNumber AS (
		SELECT TOP (@MaxToDelete+@LogMaxSize)
			ROW_NUMBER() OVER(ORDER BY EventID DESC) RowNumber
		FROM CMS_EventLog
		WHERE SiteID = @SiteId
	)
	DELETE
	FROM SiteEventsRowNumber
	WHERE RowNumber > @LogMaxSize
END
ELSE
BEGIN
	;WITH GlobalEventsRowNumber AS (
		SELECT TOP (@MaxToDelete+@LogMaxSize)
			ROW_NUMBER() OVER(ORDER BY EventID DESC) RowNumber
		FROM CMS_EventLog
		WHERE SiteID IS NULL
	)
	DELETE
	FROM GlobalEventsRowNumber
	WHERE RowNumber > @LogMaxSize

	DELETE E
	FROM CMS_EventLog E
	LEFT JOIN CMS_Site S
		ON S.SiteID = E.SiteID
	WHERE E.SiteID IS NOT NULL
		AND S.SiteID IS NULL

END



GO
