-- HF12-8 - [SECURITY] Missing access controls in Forums and Group Forums UI
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')

IF @HOTFIXVERSION < 2
BEGIN
	UPDATE [CMS_UIElement] SET [ElementAccessCondition] = N'{% CurrentUser.IsAuthorizedPerGroup(EditedObjectParent.GroupGroupID, "Read", CurrentSiteID) @%}'
	WHERE [ElementGUID] = 'DE463408-6153-447B-B7AC-785479D98087'
END
GO

-- HF12-32 Shorten 'Execute Azure search tasks' scheduled task interval
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 5
BEGIN

DECLARE @taskResourceID int;
SET @taskResourceID = (SELECT TOP 1 [ResourceID] FROM [CMS_Resource] WHERE [ResourceGUID] = '6b0a5d42-3671-4eec-8d05-0d3d249ef207')
IF @taskResourceID IS NOT NULL BEGIN

DECLARE @interval nvarchar(1000);
SET @interval = (SELECT TOP 1 [TaskInterval] FROM [CMS_ScheduledTask] WHERE [TaskGUID] = '5efb0637-041c-4260-b570-05eff059ee91')
  IF (@interval LIKE N'hour;%' AND @interval LIKE N'%;4;%')
  BEGIN
   -- Shorten the interval from 4 hours to 1 minute, if not already customized
	SET @interval = REPLACE(@interval, N'hour;', N'minute;')
	SET @interval = REPLACE(@interval, N';4;', N';1;')

	UPDATE [CMS_ScheduledTask] SET [TaskInterval] = @interval WHERE [TaskGUID] = '5efb0637-041c-4260-b570-05eff059ee91'
  END

END

END

GO

/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '5' WHERE KeyName = N'CMSHotfixVersion'
GO
